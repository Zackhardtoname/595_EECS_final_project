#!/bin/sh
source ../../bin/activate
python3 pytorch_reimpl.py